
undefined4
FUN_0800c5c8(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined1 auStack_20 [24];
  
  FUN_0800bcd4(auStack_20,param_3,param_4);
  uVar1 = FUN_080227a8(param_2,auStack_20,param_5);
  FUN_08006cec(auStack_20);
  return uVar1;
}

