
undefined4
FUN_08009696(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined1 param_5
            ,undefined4 param_6,undefined1 param_7,undefined4 param_8)

{
  undefined1 auStack_2c [24];
  undefined4 local_14;
  
  local_14 = 0;
  FUN_08009150(auStack_2c,param_8);
  FUN_0800ce66(param_1,0,*(undefined4 *)(param_2 + 8),param_3,param_4,param_5,param_6,param_7,0,0,
               auStack_2c);
  FUN_08009636(auStack_2c);
  return param_1;
}

