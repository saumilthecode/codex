
undefined4 FUN_0800bee0(undefined4 param_1)

{
  FUN_0800beb8();
  thunk_FUN_080249c4(param_1);
  return param_1;
}

