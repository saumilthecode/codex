
uint FUN_080002a8(undefined4 param_1,undefined4 param_2,uint param_3)

{
  FUN_08004974(DAT_080002bc,param_2,param_3 & 0xffff,0xffffffff);
  return param_3;
}

