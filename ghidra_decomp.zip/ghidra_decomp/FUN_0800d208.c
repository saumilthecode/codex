
undefined4 * FUN_0800d208(undefined4 *param_1)

{
  *param_1 = DAT_0800d218;
  FUN_080088f8();
  return param_1;
}

