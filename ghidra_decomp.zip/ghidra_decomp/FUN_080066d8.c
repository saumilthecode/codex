
void FUN_080066d8(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_080066e8(param_3,param_4,param_1,param_2);
  return;
}

