
int * FUN_0800afc4(int *param_1,int param_2,undefined4 param_3,undefined4 param_4,int param_5)

{
  FUN_0800ae80();
  if (param_5 != 0) {
    FUN_0800ac7a(*param_1 + param_2 * 4,param_4,param_5);
  }
  return param_1;
}

