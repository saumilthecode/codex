
void FUN_08005280(void)

{
  return;
}

