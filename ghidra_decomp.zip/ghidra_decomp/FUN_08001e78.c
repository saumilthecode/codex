
uint FUN_08001e78(void)

{
  return *DAT_08001e90 >>
         *(sbyte *)(DAT_08001e94 + ((uint)(*(int *)(DAT_08001e8c + 8) << 0x13) >> 0x1d));
}

