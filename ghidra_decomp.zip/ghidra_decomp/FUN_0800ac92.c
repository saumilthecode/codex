
void FUN_0800ac92(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  if (param_3 == 1) {
    *param_1 = *param_2;
  }
  else if (param_3 != 0) {
    FUN_080268f0(param_1,param_2,param_3 << 2);
    return;
  }
  return;
}

