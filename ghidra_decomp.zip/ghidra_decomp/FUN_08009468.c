
undefined4 * FUN_08009468(undefined4 *param_1)

{
  *param_1 = DAT_0800948c;
  FUN_0800928e(param_1 + 3);
  *param_1 = DAT_08009490;
  FUN_0801f738(param_1 + 2);
  FUN_080088f8(param_1);
  return param_1;
}

