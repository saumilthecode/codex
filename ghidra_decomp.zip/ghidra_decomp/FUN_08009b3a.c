
void FUN_08009b3a(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,int param_7,int param_8)

{
  undefined1 auStack_1c [4];
  undefined4 local_18;
  undefined4 local_14;
  
  local_18 = FUN_080090e8(param_7,param_8 + param_7,auStack_1c);
  FUN_0801121a(&local_14,param_2,param_4,param_5,param_6,&local_18);
  FUN_08009150(param_3,&local_14);
  FUN_080091fc(local_14);
  FUN_080091fc(local_18);
  return;
}

