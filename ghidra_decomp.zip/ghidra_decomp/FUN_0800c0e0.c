
undefined4 FUN_0800c0e0(undefined4 param_1)

{
  FUN_0800c0bc();
  thunk_FUN_080249c4(param_1);
  return param_1;
}

