
undefined4
FUN_0800ce66(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined1 param_6,undefined4 param_7,undefined1 param_8,
            undefined4 param_9,undefined4 param_10,int param_11)

{
  undefined1 auStack_40 [24];
  
  if (param_11 == 0) {
    FUN_08021f4a(param_1,param_3,param_4,param_5,param_6,param_7,param_8);
  }
  else {
    FUN_0800cde0(auStack_40);
    FUN_08021f7e(param_1,param_3,param_4,param_5,param_6,param_7,param_8,auStack_40);
    FUN_08006cec(auStack_40);
  }
  return param_1;
}

