
undefined4 FUN_0800a648(int *param_1)

{
  return *(undefined4 *)(*param_1 + -0xc);
}

