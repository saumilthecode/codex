
int * FUN_080089f4(int *param_1)

{
  if (*param_1 != *DAT_08008a0c) {
    FUN_080089d6();
  }
  return param_1;
}

