
undefined4 * FUN_080094a8(undefined4 *param_1)

{
  *param_1 = DAT_080094c4;
  FUN_0800928e(param_1 + 2);
  *param_1 = DAT_080094c8;
  FUN_080088f8(param_1);
  return param_1;
}

