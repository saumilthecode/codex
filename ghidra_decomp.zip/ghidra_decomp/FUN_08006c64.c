
undefined4 * FUN_08006c64(undefined4 *param_1)

{
  *param_1 = DAT_08006c7c;
  FUN_08018468();
  thunk_FUN_080249c4(param_1,4);
  return param_1;
}

