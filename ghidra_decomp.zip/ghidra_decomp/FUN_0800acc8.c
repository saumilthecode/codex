
void FUN_0800acc8(undefined4 param_1,int param_2,int param_3,undefined4 param_4)

{
  FUN_0800ac7a(param_1,param_2,param_3 - param_2 >> 2,param_4,param_4);
  return;
}

