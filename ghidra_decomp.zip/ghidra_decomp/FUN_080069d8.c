
undefined8 FUN_080069d8(undefined8 *param_1)

{
  return *param_1;
}

