
undefined4 * FUN_08008488(undefined4 *param_1)

{
  *param_1 = DAT_08008498;
  FUN_0801ee54();
  return param_1;
}

