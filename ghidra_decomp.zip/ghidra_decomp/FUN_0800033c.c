
undefined4 FUN_0800033c(void)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_080285f8();
  *puVar1 = 0x16;
  return 0xffffffff;
}

