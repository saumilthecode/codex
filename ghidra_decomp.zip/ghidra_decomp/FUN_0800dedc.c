
void FUN_0800dedc(int *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0800dee4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x28))();
  return;
}

