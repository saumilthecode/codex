
undefined4 * FUN_0800d258(undefined4 *param_1)

{
  *param_1 = DAT_0800d268;
  FUN_080088f8();
  return param_1;
}

