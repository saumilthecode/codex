
undefined4 FUN_08000338(void)

{
  return 1;
}

