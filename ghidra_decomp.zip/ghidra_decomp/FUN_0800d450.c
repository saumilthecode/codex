
undefined4 FUN_0800d450(undefined4 param_1,int param_2)

{
  FUN_0800d3dc(param_1,*(undefined4 *)(*(int *)(param_2 + 8) + 8));
  return param_1;
}

