
undefined4 * FUN_0800bef4(undefined4 *param_1)

{
  *param_1 = DAT_0800bf0c;
  FUN_0800928e(param_1 + 4);
  FUN_0800d280(param_1);
  return param_1;
}

