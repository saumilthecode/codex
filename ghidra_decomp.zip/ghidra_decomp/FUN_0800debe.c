
undefined4 FUN_0800debe(undefined4 param_1,int *param_2)

{
  (**(code **)(*param_2 + 0x1c))();
  return param_1;
}

