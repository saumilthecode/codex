
void FUN_0800acaa(undefined4 *param_1,int param_2,undefined4 param_3)

{
  if (param_2 == 1) {
    *param_1 = param_3;
  }
  else if (param_2 != 0) {
    FUN_080269cc(param_1,param_3,param_2);
    return;
  }
  return;
}

