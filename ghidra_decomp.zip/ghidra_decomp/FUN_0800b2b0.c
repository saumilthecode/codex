
undefined4 * FUN_0800b2b0(undefined4 *param_1)

{
  *param_1 = DAT_0800b2d4;
  FUN_0801f738(param_1 + 2);
  if ((*(char *)(param_1 + 3) != '\0') && (param_1[6] != 0)) {
    thunk_FUN_080249c4();
  }
  FUN_080088f8(param_1);
  return param_1;
}

