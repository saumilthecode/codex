
void FUN_0800d670(int *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0800d67a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x2c))();
  return;
}

