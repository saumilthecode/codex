
uint FUN_0800acdc(undefined4 param_1,uint param_2,undefined4 param_3,undefined4 param_4)

{
  uint uVar1;
  
  uVar1 = FUN_0800acd4();
  if (uVar1 < param_2) {
    FUN_08010508(DAT_0800acfc,param_3,param_2,uVar1,param_4);
  }
  return param_2;
}

