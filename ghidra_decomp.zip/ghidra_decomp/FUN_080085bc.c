
void FUN_080085bc(void)

{
  undefined4 in_r3;
  
  FUN_08008650(DAT_080085d4);
  FUN_08007db4(DAT_080085d4,DAT_080085dc,DAT_080085d8,in_r3);
  return;
}

