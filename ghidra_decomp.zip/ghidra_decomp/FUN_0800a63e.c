
void FUN_0800a63e(undefined4 param_1,int param_2,int param_3,undefined4 param_4)

{
  FUN_0800a5f0(param_1,param_2,param_3 - param_2,param_4,param_4);
  return;
}

