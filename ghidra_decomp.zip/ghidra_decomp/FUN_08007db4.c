
void FUN_08007db4(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  if (DAT_08025800 != 0) {
    FUN_08028698(2,param_2,param_1,param_3);
  }
  return;
}

