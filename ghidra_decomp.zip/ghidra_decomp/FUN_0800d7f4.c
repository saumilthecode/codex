
undefined4
FUN_0800d7f4(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,
            undefined1 param_5,undefined4 param_6,undefined4 param_7)

{
  (**(code **)(*param_2 + 8))(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  return param_1;
}

