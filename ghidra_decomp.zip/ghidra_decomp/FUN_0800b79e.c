
void FUN_0800b79e(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  FUN_080097da(0,*(undefined4 *)(param_1 + 0xc),param_2,param_3,param_4,param_5);
  return;
}

