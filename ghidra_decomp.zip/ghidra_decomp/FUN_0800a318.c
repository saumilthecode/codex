
undefined4
FUN_0800a318(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined1 param_6,undefined4 param_7,undefined1 param_8,
            undefined4 param_9,undefined4 param_10,int param_11)

{
  undefined4 local_2c;
  
  if (param_11 == 0) {
    FUN_08010dfa(param_1,param_3,param_4,param_5,param_6,param_7,param_8);
  }
  else {
    FUN_0800a2f0(&local_2c);
    FUN_08010e2e(param_1,param_3,param_4,param_5,param_6,param_7,param_8,&local_2c);
    FUN_080091fc(local_2c);
  }
  return param_1;
}

