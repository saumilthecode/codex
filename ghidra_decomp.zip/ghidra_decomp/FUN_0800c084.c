
undefined4 * FUN_0800c084(undefined4 *param_1)

{
  *param_1 = DAT_0800c0a0;
  FUN_0800928e(param_1 + 2);
  *param_1 = DAT_0800c0a4;
  FUN_080088f8(param_1);
  return param_1;
}

