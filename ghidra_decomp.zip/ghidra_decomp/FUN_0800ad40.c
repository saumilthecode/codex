
bool FUN_0800ad40(void)

{
  int iVar1;
  
  iVar1 = FUN_0800acd4();
  return iVar1 == 0;
}

