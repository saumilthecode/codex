
undefined4 * FUN_0800be14(undefined4 *param_1)

{
  *param_1 = DAT_0800be2c;
  FUN_0800928e(param_1 + 4);
  FUN_08021a90(param_1);
  return param_1;
}

