
void FUN_080091fc(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_c = param_2;
  uStack_8 = param_3;
  FUN_0800a7fc(param_1 + -0xc,&uStack_c,param_3,param_4,param_1);
  return;
}

