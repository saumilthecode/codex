
void FUN_08001fa4(void)

{
  return;
}

