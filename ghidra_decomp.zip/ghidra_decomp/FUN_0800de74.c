
void FUN_0800de74(int *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0800de7c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x24))();
  return;
}

