
undefined4 FUN_080066e8(undefined4 param_1)

{
  FUN_0800665c();
  return param_1;
}

