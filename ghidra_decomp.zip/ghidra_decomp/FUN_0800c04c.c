
undefined4 * FUN_0800c04c(undefined4 *param_1)

{
  *param_1 = DAT_0800c068;
  FUN_0800928e(param_1 + 2);
  *param_1 = DAT_0800c06c;
  FUN_080088f8(param_1);
  return param_1;
}

