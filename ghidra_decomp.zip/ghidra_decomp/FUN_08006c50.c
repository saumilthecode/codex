
undefined4 * FUN_08006c50(undefined4 *param_1)

{
  *param_1 = DAT_08006c60;
  FUN_08018468();
  return param_1;
}

