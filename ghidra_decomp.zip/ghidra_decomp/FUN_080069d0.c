
void FUN_080069d0(undefined4 param_1)

{
  undefined4 in_cr0;
  
  coprocessor_store(0xb,in_cr0,param_1);
  return;
}

