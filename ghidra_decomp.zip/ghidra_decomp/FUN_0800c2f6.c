
void FUN_0800c2f6(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined1 auStack_20 [24];
  
  FUN_0800e08c(auStack_20,param_2,param_4,param_5);
  FUN_0800bd1c(param_3,auStack_20);
  FUN_0801e9cc(auStack_20);
  return;
}

