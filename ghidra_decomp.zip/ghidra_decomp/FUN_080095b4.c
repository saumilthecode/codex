
undefined4 FUN_080095b4(undefined4 param_1)

{
  FUN_08009590();
  thunk_FUN_080249c4(param_1);
  return param_1;
}

