
void FUN_0800adb8(int *param_1,int param_2)

{
  if (param_1 != DAT_0800adcc) {
    param_1[2] = 0;
    *param_1 = param_2;
    param_1[param_2 + 3] = 0;
  }
  return;
}

