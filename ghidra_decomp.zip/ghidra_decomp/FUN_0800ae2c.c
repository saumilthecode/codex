
int FUN_0800ae2c(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  
  iVar1 = DAT_0800ae5c;
  if (param_1 != 0) {
    iVar1 = FUN_0800add0(param_1,0,param_3,param_4,param_4);
    FUN_0800acaa(iVar1 + 0xc,param_1,param_2);
    FUN_0800adb8(iVar1,param_1);
    iVar1 = iVar1 + 0xc;
  }
  return iVar1;
}

