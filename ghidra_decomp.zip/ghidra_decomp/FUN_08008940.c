
int FUN_08008940(void)

{
  int *piVar1;
  
  piVar1 = DAT_08008950;
  if (*DAT_08008950 == 0) {
    FUN_08008928();
  }
  return *piVar1;
}

