
int FUN_0800aa50(int *param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  
  iVar1 = FUN_0800a764(param_3 + *param_1,param_1[1],param_2);
  if (*param_1 != 0) {
    FUN_0800a5f0(iVar1 + 0xc,param_1 + 3);
  }
  FUN_0800a74c(iVar1,*param_1);
  return iVar1 + 0xc;
}

