
undefined4 FUN_0800bdc4(undefined4 param_1)

{
  FUN_0800bd9c();
  thunk_FUN_080249c4(param_1);
  return param_1;
}

