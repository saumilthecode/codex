
void FUN_0800a608(undefined1 *param_1,undefined1 *param_2,int param_3)

{
  if (param_3 == 1) {
    *param_1 = *param_2;
  }
  else if (param_3 != 0) {
    FUN_080268f0();
    return;
  }
  return;
}

