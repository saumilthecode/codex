
bool FUN_08006748(void)

{
  char in_CY;
  
  FUN_080066d8();
  return in_CY == '\0';
}

