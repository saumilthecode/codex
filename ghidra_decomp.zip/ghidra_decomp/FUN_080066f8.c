
bool FUN_080066f8(void)

{
  char in_ZR;
  
  FUN_080066e8();
  return in_ZR != '\0';
}

