
undefined4 * FUN_08009438(undefined4 *param_1)

{
  *param_1 = DAT_08009450;
  FUN_0800928e(param_1 + 4);
  FUN_08018704(param_1);
  return param_1;
}

