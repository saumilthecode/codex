
int * FUN_0800a9a8(int *param_1,int param_2,undefined4 param_3,undefined4 param_4,int param_5)

{
  FUN_0800a844();
  if (param_5 != 0) {
    FUN_0800a5f0(*param_1 + param_2,param_4,param_5);
  }
  return param_1;
}

