
undefined4 FUN_080011bc(int param_1)

{
  return *(undefined4 *)(param_1 + 0x54);
}

