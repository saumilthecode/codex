
void FUN_08005268(void)

{
  return;
}

