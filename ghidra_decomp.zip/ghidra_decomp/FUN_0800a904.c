
void FUN_0800a904(int *param_1)

{
  if (-1 < *(int *)(*param_1 + -4)) {
    FUN_0800a8d8();
  }
  return;
}

