
void FUN_08003604(void)

{
  return;
}

