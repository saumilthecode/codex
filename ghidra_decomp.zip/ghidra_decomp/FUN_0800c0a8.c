
undefined4 FUN_0800c0a8(undefined4 param_1)

{
  FUN_0800c084();
  thunk_FUN_080249c4(param_1);
  return param_1;
}

