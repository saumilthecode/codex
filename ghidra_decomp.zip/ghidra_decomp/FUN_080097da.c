
void FUN_080097da(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
                    /* WARNING: Could not recover jumptable at 0x08011242. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_2 + 8))(param_2,param_3,param_4,param_5);
  return;
}

