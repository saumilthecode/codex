
void FUN_08009b7e(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,int param_7,int param_8)

{
  undefined1 auStack_1c [4];
  undefined4 local_18;
  undefined4 local_14;
  
  local_18 = FUN_0800909c(param_7,param_7 + param_8 * 4,auStack_1c);
  FUN_08018e3a(&local_14,param_2,param_4,param_5,param_6,&local_18);
  FUN_08009214(param_3,&local_14);
  FUN_08009134(local_14);
  FUN_08009134(local_18);
  return;
}

