
undefined4 FUN_08008442(code *param_1)

{
  (*param_1)();
  FUN_08008438();
  DataMemoryBarrier(0x1b);
  return *DAT_08008458;
}

