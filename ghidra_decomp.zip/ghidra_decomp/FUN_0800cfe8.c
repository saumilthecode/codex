
undefined4
FUN_0800cfe8(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined1 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,int param_11)

{
  undefined1 auStack_40 [24];
  
  if (param_11 == 0) {
    FUN_0800d7f4(param_1,param_3,param_4,param_5,param_6,param_7,param_8);
  }
  else {
    FUN_0800cfb0(auStack_40);
    FUN_0800d826(param_1,param_3,param_4,param_5,param_6,param_7,param_8,auStack_40);
    FUN_0801e9cc(auStack_40);
  }
  return param_1;
}

