
undefined4 * FUN_0800d230(undefined4 *param_1)

{
  *param_1 = DAT_0800d240;
  FUN_080088f8();
  return param_1;
}

