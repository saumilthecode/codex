
bool FUN_0800670c(void)

{
  char in_CY;
  
  FUN_080066e8();
  return in_CY == '\0';
}

