
undefined4 FUN_0800de60(undefined4 param_1,int *param_2)

{
  (**(code **)(*param_2 + 0x1c))();
  return param_1;
}

