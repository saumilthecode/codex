
undefined4
FUN_0800bbbe(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined1 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  FUN_0800a49c(param_1,0,*(undefined4 *)(param_2 + 8),param_3,param_4,param_5,param_6,param_7,
               param_9,param_10,0);
  return param_1;
}

