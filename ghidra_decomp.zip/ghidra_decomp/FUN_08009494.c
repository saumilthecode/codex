
undefined4 FUN_08009494(undefined4 param_1)

{
  FUN_08009468();
  thunk_FUN_080249c4(param_1);
  return param_1;
}

