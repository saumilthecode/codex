
undefined4
FUN_08009aea(undefined4 param_1,undefined4 param_2,int param_3,int param_4,undefined4 param_5)

{
  undefined4 uVar1;
  undefined4 uStack_10;
  undefined4 local_c;
  
  uStack_10 = param_1;
  local_c = param_2;
  local_c = FUN_080090e8(param_3,param_3 + param_4,&uStack_10);
  uVar1 = FUN_08011214(param_2,&local_c,param_5);
  FUN_080091fc(local_c);
  return uVar1;
}

