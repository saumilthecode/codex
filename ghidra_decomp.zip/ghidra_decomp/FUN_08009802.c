
void FUN_08009802(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined4 local_c;
  
  local_c = param_2;
  FUN_08011244(&local_c,param_2,param_4,param_5,param_1);
  FUN_08009150(param_3,&local_c);
  FUN_080091fc(local_c);
  return;
}

