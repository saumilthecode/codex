
void FUN_0800a620(undefined1 *param_1,int param_2,undefined4 param_3)

{
  if (param_2 == 1) {
    *param_1 = (char)param_3;
  }
  else if (param_2 != 0) {
    FUN_08026922(param_1,param_3,param_2);
    return;
  }
  return;
}

