
int * FUN_0800af8c(int *param_1,int param_2,undefined4 param_3,int param_4,undefined4 param_5)

{
  FUN_0800ad00(param_1,param_3,param_4,DAT_0800afc0,param_4);
  FUN_0800ae80(param_1,param_2,param_3,param_4);
  if (param_4 != 0) {
    FUN_0800acaa(*param_1 + param_2 * 4,param_4,param_5);
  }
  return param_1;
}

