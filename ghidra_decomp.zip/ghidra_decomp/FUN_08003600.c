
void FUN_08003600(void)

{
  return;
}

