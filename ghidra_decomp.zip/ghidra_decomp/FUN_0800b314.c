
undefined4 * FUN_0800b314(undefined4 *param_1)

{
  *param_1 = DAT_0800b330;
  FUN_0801f738(param_1 + 2);
  *param_1 = DAT_0800b334;
  FUN_080088f8(param_1);
  return param_1;
}

