
undefined4 FUN_08007f18(void)

{
  return DAT_08007f1c;
}

