
undefined4 * FUN_08009358(undefined4 *param_1)

{
  *param_1 = DAT_08009370;
  FUN_0800928e(param_1 + 4);
  FUN_08010b18(param_1);
  return param_1;
}

