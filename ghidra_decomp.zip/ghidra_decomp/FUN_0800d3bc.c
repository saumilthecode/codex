
undefined4 FUN_0800d3bc(undefined4 param_1,int param_2)

{
  FUN_0800d32c(param_1,*(undefined4 *)(*(int *)(param_2 + 8) + 0x24));
  return param_1;
}

