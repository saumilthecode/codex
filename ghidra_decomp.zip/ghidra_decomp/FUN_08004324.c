
void FUN_08004324(void)

{
  return;
}

