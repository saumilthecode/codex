
void thunk_FUN_080249c4(undefined4 param_1)

{
  FUN_08028790(*DAT_080249d0,param_1);
  return;
}

