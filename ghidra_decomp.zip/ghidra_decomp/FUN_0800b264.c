
void FUN_0800b264(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0800b224(param_1,param_2,0,param_4,param_4);
  return;
}

