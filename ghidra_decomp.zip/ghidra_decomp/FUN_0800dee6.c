
void FUN_0800dee6(int *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0800deea. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 8))();
  return;
}

