
void FUN_0800deec(int *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0800def0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0xc))();
  return;
}

