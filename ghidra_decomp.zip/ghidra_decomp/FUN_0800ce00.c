
undefined4 FUN_0800ce00(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 auStack_24 [24];
  undefined4 local_c;
  
  local_c = 0;
  FUN_08009802(0,*(undefined4 *)(param_2 + 0xc),auStack_24,param_3,param_4);
  FUN_0800cde0(param_1,auStack_24);
  FUN_08009636(auStack_24);
  return param_1;
}

