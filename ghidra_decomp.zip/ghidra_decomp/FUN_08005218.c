
void FUN_08005218(void)

{
  return;
}

