
undefined4 * FUN_08009590(undefined4 *param_1)

{
  *param_1 = DAT_080095ac;
  FUN_0800928e(param_1 + 2);
  *param_1 = DAT_080095b0;
  FUN_080088f8(param_1);
  return param_1;
}

