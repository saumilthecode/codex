
bool FUN_0800a6b2(void)

{
  int iVar1;
  
  iVar1 = FUN_0800a648();
  return iVar1 == 0;
}

