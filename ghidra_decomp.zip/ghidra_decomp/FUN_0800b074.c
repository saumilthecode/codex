
int FUN_0800b074(int *param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  
  iVar1 = FUN_0800add0(param_3 + *param_1,param_1[1],param_2);
  if (*param_1 != 0) {
    FUN_0800ac7a(iVar1 + 0xc,param_1 + 3);
  }
  FUN_0800adb8(iVar1,*param_1);
  return iVar1 + 0xc;
}

