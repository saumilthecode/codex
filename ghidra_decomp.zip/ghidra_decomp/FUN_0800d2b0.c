
undefined4 * FUN_0800d2b0(undefined4 *param_1)

{
  *param_1 = DAT_0800d2c8;
  FUN_0801f738(param_1 + 2);
  FUN_080088f8(param_1);
  return param_1;
}

