
undefined4
FUN_0800ddf8(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            char param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  if (param_5 == '\0') {
    FUN_0800daac(param_1,param_2,param_3,param_4,param_6,param_7,param_8);
  }
  else {
    FUN_0800d854();
  }
  return param_1;
}

