
bool FUN_08006918(void)

{
  undefined1 in_ZR;
  undefined1 in_CY;
  
  FUN_080068e0();
  return !(bool)in_CY || (bool)in_ZR;
}

