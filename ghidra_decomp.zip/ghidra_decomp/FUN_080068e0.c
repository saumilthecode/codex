
undefined8 FUN_080068e0(undefined4 param_1,undefined4 param_2)

{
  FUN_08006878();
  return CONCAT44(param_2,param_1);
}

