
void FUN_080069c8(undefined4 param_1)

{
  undefined4 in_cr0;
  
  coprocessor_load(0xb,in_cr0,param_1);
  return;
}

