
void FUN_0800c618(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined1 auStack_48 [24];
  undefined1 auStack_30 [28];
  
  FUN_0800bcd4(auStack_48,param_7,param_8);
  FUN_080227ae(auStack_30,param_2,param_4,param_5,param_6,auStack_48);
  FUN_0800bd3c(param_3,auStack_30);
  FUN_08006cec(auStack_30);
  FUN_08006cec(auStack_48);
  return;
}

