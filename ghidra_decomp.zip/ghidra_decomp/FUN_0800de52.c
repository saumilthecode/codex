
undefined4 FUN_0800de52(undefined4 param_1,int *param_2)

{
  (**(code **)(*param_2 + 0x18))();
  return param_1;
}

