
void FUN_0800a5f0(undefined1 *param_1,undefined1 *param_2,int param_3)

{
  if (param_3 == 1) {
    *param_1 = *param_2;
  }
  else if (param_3 != 0) {
    FUN_08028666();
    return;
  }
  return;
}

