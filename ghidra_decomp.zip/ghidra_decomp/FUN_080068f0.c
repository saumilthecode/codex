
bool FUN_080068f0(void)

{
  char in_ZR;
  
  FUN_080068e0();
  return in_ZR != '\0';
}

