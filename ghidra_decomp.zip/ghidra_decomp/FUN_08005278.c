
void FUN_08005278(void)

{
  return;
}

