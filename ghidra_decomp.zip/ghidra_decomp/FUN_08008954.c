
undefined4 FUN_08008954(void)

{
  return DAT_08008958;
}

