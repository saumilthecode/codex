
undefined4 FUN_080003a8(void)

{
  return 0;
}

