
undefined4
FUN_0800c15c(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined1 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined1 auStack_2c [24];
  undefined4 local_14;
  
  local_14 = 0;
  FUN_0800bc58(auStack_2c,param_8);
  local_14 = DAT_0800c1b4;
  FUN_0800a49c(param_1,0,*(undefined4 *)(param_2 + 8),param_3,param_4,param_5,param_6,param_7,0,0,
               auStack_2c);
  FUN_08009636(auStack_2c);
  return param_1;
}

