
undefined8 FUN_080069b0(undefined8 *param_1)

{
  *(undefined4 *)(*(int *)((int)param_1 + 0x34) + -4) = *(undefined4 *)((int)param_1 + 0x3c);
  return *param_1;
}

