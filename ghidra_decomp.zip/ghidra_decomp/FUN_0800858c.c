
undefined4 FUN_0800858c(void)

{
  return 0;
}

