
void FUN_0800ad00(undefined4 param_1,int param_2,uint param_3,undefined4 param_4)

{
  int iVar1;
  
  iVar1 = FUN_0800acd4();
  if ((uint)((param_2 + 0xffffffe) - iVar1) < param_3) {
    FUN_08010502(param_4);
  }
  return;
}

