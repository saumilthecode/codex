
undefined4 FUN_0800844c(void)

{
  DataMemoryBarrier(0x1b);
  return *DAT_08008458;
}

