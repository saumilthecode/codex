
void FUN_0800af44(int *param_1)

{
  if (-1 < *(int *)(*param_1 + -4)) {
    FUN_0800af18();
  }
  return;
}

