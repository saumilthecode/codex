
undefined4 FUN_08000390(void)

{
  return 0xffffffff;
}

