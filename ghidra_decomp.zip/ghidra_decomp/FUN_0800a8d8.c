
void FUN_0800a8d8(int *param_1)

{
  int iVar1;
  
  iVar1 = FUN_0800a6b2();
  if (iVar1 == 0) {
    if (0 < *(int *)(*param_1 + -4)) {
      FUN_0800a844(param_1,0,0,0);
    }
    *(undefined4 *)(*param_1 + -4) = 0xffffffff;
  }
  return;
}

