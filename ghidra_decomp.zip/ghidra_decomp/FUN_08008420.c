
void FUN_08008420(code *param_1)

{
  (*param_1)();
                    /* WARNING: Subroutine does not return */
  FUN_080249a4();
}

