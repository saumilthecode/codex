
void FUN_0800d460(int param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_0801ebb4(param_1,*(undefined4 *)(param_1 + 4),0,param_2,param_3,param_2,param_3);
  return;
}

