
undefined4 * FUN_0800be44(undefined4 *param_1)

{
  *param_1 = DAT_0800be64;
  *(undefined4 *)(param_1[4] + 0xc) = 0;
  FUN_0800928e(param_1 + 3);
  FUN_08020604(param_1);
  return param_1;
}

