
void FUN_0800af18(int *param_1)

{
  int iVar1;
  
  iVar1 = FUN_0800ad40();
  if (iVar1 == 0) {
    if (0 < *(int *)(*param_1 + -4)) {
      FUN_0800ae80(param_1,0,0,0);
    }
    *(undefined4 *)(*param_1 + -4) = 0xffffffff;
  }
  return;
}

