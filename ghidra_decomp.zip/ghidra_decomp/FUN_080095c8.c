
undefined4 * FUN_080095c8(undefined4 *param_1)

{
  *param_1 = DAT_080095e4;
  FUN_0800928e(param_1 + 2);
  *param_1 = DAT_080095e8;
  FUN_080088f8(param_1);
  return param_1;
}

