
undefined4 FUN_08008428(void)

{
  DataMemoryBarrier(0x1b);
  return *DAT_08008434;
}

