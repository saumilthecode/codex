
undefined4 FUN_080003a4(void)

{
  return 1;
}

