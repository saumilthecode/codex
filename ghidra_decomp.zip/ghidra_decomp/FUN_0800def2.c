
undefined4 FUN_0800def2(undefined4 param_1,int *param_2)

{
  (**(code **)(*param_2 + 0x10))();
  return param_1;
}

