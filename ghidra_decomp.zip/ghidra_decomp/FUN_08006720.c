
bool FUN_08006720(void)

{
  undefined1 in_ZR;
  undefined1 in_CY;
  
  FUN_080066e8();
  return !(bool)in_CY || (bool)in_ZR;
}

