
undefined4 FUN_0800061c(void)

{
  return *DAT_08000624;
}

