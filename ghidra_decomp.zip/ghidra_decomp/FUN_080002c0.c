
uint FUN_080002c0(undefined4 param_1,undefined4 param_2,uint param_3)

{
  FUN_08004838(DAT_080002d4,param_2,param_3 & 0xffff,0xffffffff);
  return param_3;
}

