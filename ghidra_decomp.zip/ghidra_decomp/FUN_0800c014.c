
undefined4 * FUN_0800c014(undefined4 *param_1)

{
  *param_1 = DAT_0800c030;
  FUN_0800928e(param_1 + 2);
  *param_1 = DAT_0800c034;
  FUN_080088f8(param_1);
  return param_1;
}

