
uint FUN_080006b0(void)

{
  return *DAT_080006b8 >> 0x10;
}

