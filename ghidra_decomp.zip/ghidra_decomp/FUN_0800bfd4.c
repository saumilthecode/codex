
undefined4 * FUN_0800bfd4(undefined4 *param_1)

{
  *param_1 = DAT_0800bff8;
  FUN_0800928e(param_1 + 3);
  *param_1 = DAT_0800bffc;
  FUN_0801f738(param_1 + 2);
  FUN_080088f8(param_1);
  return param_1;
}

