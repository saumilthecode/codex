
void FUN_0800de30(int *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0800de34. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0xc))();
  return;
}

