
undefined4
FUN_0800ce2a(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 *param_6)

{
  undefined1 auStack_2c [24];
  undefined4 local_14;
  
  local_14 = 0;
  FUN_08009b3a(0,*(undefined4 *)(param_2 + 0x10),auStack_2c,param_3,param_4,param_5,*param_6,
               param_6[1]);
  FUN_0800cde0(param_1,auStack_2c);
  FUN_08009636(auStack_2c);
  return param_1;
}

