
int * FUN_0800a94c(int *param_1,int param_2,undefined4 param_3,int param_4,undefined1 param_5)

{
  FUN_0800a674(param_1,param_3,param_4,DAT_0800a980,param_4);
  FUN_0800a844(param_1,param_2,param_3,param_4);
  if (param_4 != 0) {
    FUN_0800a620(*param_1 + param_2,param_4,param_5);
  }
  return param_1;
}

