
undefined4 FUN_0800d39c(undefined4 param_1,int param_2)

{
  FUN_0800d32c(param_1,*(undefined4 *)(*(int *)(param_2 + 8) + 0x1c));
  return param_1;
}

