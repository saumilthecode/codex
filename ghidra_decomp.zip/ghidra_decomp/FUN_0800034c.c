
void FUN_0800034c(void)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_080285f8();
  *puVar1 = 0x16;
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}

