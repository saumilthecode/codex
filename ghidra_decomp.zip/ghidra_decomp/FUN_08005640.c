
void FUN_08005640(void)

{
  return;
}

